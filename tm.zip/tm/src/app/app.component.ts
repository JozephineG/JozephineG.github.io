import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'app';
  ngOnInit() {
  }
  constructor( private route: ActivatedRoute, private router: Router) { 
    this.route.params.subscribe(res => console.log(res.id));
  }

  sendMeHome(){
    this.router.navigate(['/home']);
  }
  sendMeAbout(){
    this.router.navigate(['/about']);
  }
  sendMeContact(){
    this.router.navigate(['/contact']);
  }
}
