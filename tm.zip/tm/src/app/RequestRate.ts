export class RequestRate {
    constructor(
        public amount: number,
        public convert: string,
        public base: string,
      ) {  }
}