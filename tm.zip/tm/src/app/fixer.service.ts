import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { RequestRate } from './RequestRate';

@Injectable()
export class FixerService {

  constructor(private http: HttpClient) {

  }

  getExchangeRates() {
    return this.http.get("http://data.fixer.io/api/latest?access_key=ecf13c56eba7eaca37bacc90ad006885&symbols=SEK,NOK,AED,USD&format=1");
  }

}
