export class ExchangeRate {
    constructor(
        public convertedAmount: number,
        public convert: string,
        public base: string,
      ) {  }
}