import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';
import { FixerService } from '../fixer.service';
import { ExchangeRate } from '../ExchangeRate';
import { RequestRate } from '../RequestRate';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor( private route: ActivatedRoute, private router: Router, private fixerService: FixerService) { 
    this.route.params.subscribe(res => console.log(res.id));
  }

  baseCurrency = ['EUR']
  convertToCurrencies = ['SEK', 'NOK', 'AED', 'USD']
  model = new RequestRate(1, 'EUR', 'SEK')
  exchangeResult: ExchangeRate;

  ngOnInit() {
  }

  sendMeHome(){
    this.router.navigate(['']);
  }

  onSubmit() {
    let exchangeRates = this.fixerService.getExchangeRates()
    exchangeRates.subscribe(data => this.exchangeResult = {
      convertedAmount:this.model.amount * data['rates'][this.model.convert],
      base: this.model.base,
      convert: this.model.convert
    });
  }
  get result() {
    if (this.exchangeResult != undefined) {
      var amount = this.model.amount
      return amount + this.exchangeResult.base + " = " + this.exchangeResult.convertedAmount.toFixed(2) + this.exchangeResult.convert
    }
  }
}
